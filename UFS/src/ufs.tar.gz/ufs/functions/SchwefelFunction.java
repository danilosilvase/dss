package ufs.functions;

import ufs.core.Function;
import ufs.core.Solution;

public class SchwefelFunction extends Function {

	@Override
	public double quality(Solution s) {
		contAvaliacao();
		double[] arraySolution = s.getArraySolution();
		double maximo = 0.0;
		for (int i = 0; i < arraySolution.length; i++) {
			if (maximo < Math.abs(arraySolution[i])) {
				maximo = Math.abs(arraySolution[i]);
			}
		}
		return maximo;
	}

}
