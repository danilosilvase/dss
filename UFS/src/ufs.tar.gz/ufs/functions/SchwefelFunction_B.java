package ufs.functions;

import ufs.core.Function;
import ufs.core.Solution;

public class SchwefelFunction_B extends Function {

	@Override
	public double quality(Solution soluction) {
		double result = 0;

		for (int i = 0; i < soluction.getArraySolution().length; i++) {
			if (Math.abs(soluction.getArraySolution()[i]) > result)
				result = Math.abs(soluction.getArraySolution()[i]);
		}

		soluction.setObjetivo(result);

		return result;
	}

}
