package ufs.functions;

import ufs.core.Function;
import ufs.core.Solution;

public class SphereFunction_B extends Function {

	@Override
	public double quality(Solution soluction) {
		double result = 0;

		for (int i = 0; i < soluction.getArraySolution().length; i++) {
			result += Math.pow(soluction.getArraySolution()[i], 2);
		}

		soluction.setObjetivo(result);

		return result;

	}

}
