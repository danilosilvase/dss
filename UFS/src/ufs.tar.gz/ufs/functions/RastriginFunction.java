package ufs.functions;

import ufs.core.Function;
import ufs.core.Solution;

public class RastriginFunction extends Function {

	@Override
	public double quality(Solution s) {
		contAvaliacao();
		double[] arraySolution = s.getArraySolution();
		double qualidade = 0.0;
		for (int i = 0; i < arraySolution.length; i++) {

			/*
			 * F 4 ( x ) = ∑ ( z i² − 10 cos(2 π z i ) + 10)
			 */
			qualidade += (Math.pow(arraySolution[i], 2) - (Math.cos(-10) * 2 * Math.PI * arraySolution[i]) + 10);
		}

		return qualidade;

	}

}
