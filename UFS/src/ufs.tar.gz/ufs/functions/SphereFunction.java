package ufs.functions;

import ufs.core.Function;
import ufs.core.Solution;

public class SphereFunction extends Function {

	@Override
	public double quality(Solution s) {
		contAvaliacao();
		double objetivo = 0.0;

		double[] array = s.getArraySolution();

		for (int i = 0; i < array.length; i++) {

			objetivo += (Math.pow(array[i], 2));
			//System.out.println("Obj: "+objetivo);
			if (objetivo < 0) {
				System.out.println("valor negativo" + array[i]);
			}
		}
		//s.setObjetivo(objetivo);
		return objetivo;
	}

}
