package ufs.functions;

import ufs.core.Function;
import ufs.core.Solution;

public class RosenbrockFunction extends Function {

	@Override
	public double quality(Solution s) {
		contAvaliacao();
		double[] arraySolution = s.getArraySolution();
		
		double qualidade = 0.0;

		for (int i = 0; i < arraySolution.length - 1; i++) {
			qualidade +=(Math.pow(arraySolution[i], 2) - arraySolution[i + 1]);
		}
		return qualidade;
	}

}
