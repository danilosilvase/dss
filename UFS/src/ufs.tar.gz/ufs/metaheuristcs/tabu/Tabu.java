package ufs.metaheuristcs.tabu;

import java.util.ArrayList;

import ufs.core.Algorithm;
import ufs.core.Solution;

public class Tabu extends Algorithm {

	private Solution solutionS;
	private Solution solutionR;
	private Solution solutionW;
	private int numAvaliation;
	private int listTabuSize;
	private int nunVizinhos;

	private Solution best;
	private ArrayList<Solution> listTabu;

	public Tabu(int listTabuSize, int numAvaliation, int nunVizinhos, int tWeakSize, double min, double max)
			throws CloneNotSupportedException {
		this.solutionS = new Solution(tWeakSize, min, max);
		this.numAvaliation = numAvaliation;
		this.listTabuSize = listTabuSize;
		this.nunVizinhos = nunVizinhos;

		this.best = this.solutionS.clone();
		listTabu = new ArrayList<>();
		listTabu.add(solutionS.clone());
	}

	@Override
	public Solution execute() throws CloneNotSupportedException {

		quality(this.solutionS);
		quality(this.best);

		System.out.println("Solução Inicial " + solutionS.getObjetivo());

		for (int i = 0; i < this.numAvaliation; i++) {

			if (listTabu.size() > this.listTabuSize) {
				listTabu.remove(0);
			}

			solutionR = operator.tweak(this.solutionS).clone();
			quality(solutionR);

			for (int j = 0; j < this.nunVizinhos; j++) {
				solutionW = operator.tweak(this.solutionS).clone();

				if (!this.listTabu.contains(solutionW)
						&& (quality(solutionW) < solutionR.getObjetivo() || this.listTabu.contains(solutionR))) {
					solutionR = solutionW.clone();
				}
			}

			if (!this.listTabu.contains(solutionR)) {
				this.solutionS = solutionR.clone();
				quality(this.solutionS);
				this.listTabu.add(solutionR.clone());
			}

			if (this.solutionS.getObjetivo() < quality(this.best)) {
				this.best = this.solutionS.clone();
				quality(this.best);
			}

		}
		return best;

	}

	private double quality(Solution soluction) {
		double calcFuncao = funcaoObjetivo.quality(solutionS);
		solutionS.setObjetivo(calcFuncao);
		return calcFuncao;
	}

}
