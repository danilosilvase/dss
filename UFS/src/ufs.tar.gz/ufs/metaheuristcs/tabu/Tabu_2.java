package ufs.metaheuristcs.tabu;

import java.util.ArrayList;

import ufs.core.Algorithm;
import ufs.core.Solution;

public class Tabu_2 extends Algorithm {

	private Solution solution;
	private int numAvaliation;
	private int listTabuSize;
	private int neighbors;

	private Solution best;
	private ArrayList<Tuple<Integer, Double>> listTabu;

	public Tabu_2(int listTabuSize, int numAvaliation, int neighbors, int tWeakSize, double min, double max)
			throws CloneNotSupportedException {
		this.solution = new Solution(tWeakSize, min, max);
		this.numAvaliation = numAvaliation;
		this.listTabuSize = listTabuSize;
		this.neighbors = neighbors;

		this.best = this.solution.clone();
		listTabu = new ArrayList<>();
		listTabu.add(new Tuple<>(0, 0.0));
	}

	@Override
	public Solution execute() throws CloneNotSupportedException {

		quality(this.solution);

		for (int i = 0; i < this.numAvaliation; i++) {
			if (listTabu.size() > this.listTabuSize) {
				listTabu.remove(0);
			}
			Solution newSoluction = operator.tweak(this.solution);
			quality(newSoluction);

			Tuple<Integer, Double> tupleR = new Tuple<>(newSoluction.getChangedPosition(),
					newSoluction.getChangedValue());

			for (int j = 0; j < this.neighbors; j++) {
				Solution neighSoluction = operator.tweak(this.solution);

				Tuple<Integer, Double> tupleW = new Tuple<>(neighSoluction.getChangedPosition(),
						neighSoluction.getChangedValue());

				if (!this.listTabu.contains(tupleW)
						&& (quality(neighSoluction) < newSoluction.getObjetivo() || this.listTabu.contains(tupleR))) {
					newSoluction = neighSoluction.clone();
					tupleR = new Tuple<>(newSoluction.getChangedPosition(), newSoluction.getChangedValue());
				}
			}

			if (!this.listTabu.contains(tupleR)) {
				this.solution = newSoluction.clone();
				this.solution.setLastPosition(i);

				this.listTabu.add(tupleR);
			}

			if (this.solution.getObjetivo() < quality(this.best)) {
				this.best = this.solution.clone();
			}

		}

		return this.best;
	}

	private double quality(Solution soluction) {
		double calcFuncao = funcaoObjetivo.quality(solution);
		solution.setObjetivo(calcFuncao);
		return calcFuncao;
	}

}
