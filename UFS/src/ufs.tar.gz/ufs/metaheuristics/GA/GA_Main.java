package ufs.metaheuristics.GA;

import ufs.core.*;
import ufs.functions.*;
import ufs.operators.*;

public class GA_Main {

	public static void main(String[] args) throws CloneNotSupportedException {

		Solution solution; // problema a ser resolvido
		Operator operator; // Operador Tweak
		Function function; // Funcao de avaliação
		GA algorithm; // Algoritmo escolhido

		for (int i = 0; i < 20; i++) {

			// Dimensão do array
			int dimensaoArray = 50;

			// Numero de avaliações
			int numAvaliacoes = 50000;

			// Intervalo do array
			int max = 100;
			int min = -100;
			
			//tamanho da populacao
			
			int popSize = 200;

			// Função de avaliação
			// function = new RosenbrockFunction();
			function = new RosenbrockFunction_B();
			// function = new RastriginFunction();
			// function = new RastriginFunction_B();
			// function = new SchwefelFunction();
			// function = new SchwefelFunction_B();
			// function = new SphereFunction_B();
			// function = new SphereFunction();
			
			// Operador
			operator = new Tweak_4();

			// Algoritmo
			algorithm = new GA(numAvaliacoes, dimensaoArray, popSize,  max, min);
			algorithm.setFuncaoObjetivo(function);
			algorithm.setOperator(operator);

			solution = algorithm.execute();
			function.quality(solution);
			// System.out.println("Melhor solução: " + solution.getObjetivo());
			System.out.println(solution.getObjetivo());

		}
	}

}
