package ufs.core;

public abstract class Function {

	private int avaliacao = 0;

	public int getAvaliacao() {
		return avaliacao;
	}

	public void contAvaliacao() {
		avaliacao++;
	}

	private double objetivo;

	public abstract double quality(Solution s);

	public double getObjetivo() {
		return objetivo;
	}

	public void setObjetivo(double objetivo) {
		this.objetivo = objetivo;
	}
}
